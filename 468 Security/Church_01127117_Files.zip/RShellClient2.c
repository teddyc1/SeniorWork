/*
*  CS 468 Sample Program
*
*  This program is for educational purpose, and it can not be copied as part of your submission to CS 468 HWs
*/

#include "RShellHeader1.h"
#include <time.h>
#include <stdlib.h>

// ============================================================================================
// Method to create a client sock
// ============================================================================================
int clientsock( int UDPorTCP, const char *destination, int portN )
{
	struct hostent *phe; /* pointer to host information entry	*/
	struct sockaddr_in dest_addr; /* destination endpoint address		*/
	int sock; /* socket descriptor to be allocated	*/

	bzero( (char *) &dest_addr, sizeof( dest_addr ) );
	dest_addr.sin_family = AF_INET;

	/* Set destination port number */
	dest_addr.sin_port = htons( portN );

	/* Map host name to IPv4 address, does not work well for IPv6 */
	if( ( phe = gethostbyname( destination ) ) != 0 )
		bcopy( phe->h_addr, (char *) &dest_addr.sin_addr, phe->h_length );
	else if( inet_aton( destination, &( dest_addr.sin_addr ) ) == 0 ) /* invalid destination address */
		return -2;

	/* version that support IPv6
	 else if (inet_pton(AF_INET, destination, &(dest_addr.sin_addr)) != 1)
	 */

	/* Allocate a socket */
	sock = socket( PF_INET, UDPorTCP, 0 );
	if( sock < 0 )
		return -3;

	/* Connect the socket */
	if( connect( sock, (struct sockaddr *) &dest_addr, sizeof( dest_addr ) ) < 0 )
		return -4;

	return sock;
}

int clientTCPsock( const char *destination, int portN )
{
	return clientsock( SOCK_STREAM, destination, portN );
}

int clientUDPsock( const char *destination, int portN )
{
	return clientsock( SOCK_DGRAM, destination, portN );
}

// ============================================================================================
// Method to receive messages from socket, returns NULL if there is an error during read
// ============================================================================================
Message *recv_message( int sock )
{
	// Create a pointer to hold in the message read-in
	Message *msg = (Message *) malloc( sizeof(Message) );

	// Read the message type
	if( recv( sock, &msg->msgtype, TYPESIZE, 0 ) != TYPESIZE ) {
		print_normal( "ERROR(1): Could not read message type.\n" );
		free( msg );
		return NULL;
	}

	// Read the message length
	if( recv( sock, &msg->paylen, LENSIZE, 0 ) != LENSIZE ) {
		print_normal( "ERROR(2): Could not read message length.\n" );
		free( msg );
		return NULL;
	}

	// Read the user ID
	if( msg->paylen >= IDSIZE ) {
		if( ( recv( sock, &msg->id, IDSIZE, 0 ) ) != IDSIZE ) {
			print_normal( "ERROR(3): Could not read message ID.\n" );
			free( msg );
			return NULL;
		}
	}

	// Read the payload: malloc new memory for the incoming payload
	if( msg->paylen > IDSIZE ) {
		msg->payload = (char*) malloc( ( msg->paylen - IDSIZE + 1 ) * sizeof(char) );
		if( ( recv( sock, msg->payload, ( msg->paylen - IDSIZE ), 0 ) ) != ( msg->paylen - IDSIZE ) ) {
			print_normal( "ERROR(4): Could not read message payload.\n" );
			free_msg( &msg, true );
			return NULL;
		}
		msg->payload[msg->paylen - IDSIZE] = '\0';
	}

	// Return pointer to read-in message
	return msg;
}

// ============================================================================================
// Main
// ============================================================================================
int main(int argc, char *argv[])
{
	// Make sure there are 5 input arguments
	if( argc != 5 ) {
		fprintf( stderr, "Usage: %s <server IP> <server port number> <ID> <password> \n", argv[0] );
		exit( 1 );
	}

	// ------------------------------------------------------------------
	// Command line arg variables
	//
	// This is the ip address to connect to, in this case, localhost
	char *destination = argv[1];

	// The port number to connect to on the server
	int portN = atoi( argv[2] );

	// User id, ie "Alice"
	char *userid = argv[3];
	// Generate Nonce before the pwd is SHA1'ed
	srand(time(NULL));
	unsigned int nonce2 = rand();
	// User pwd will be hashed using SHA1.
	char *userpwd = argv[4];
	unsigned char password[PASSWDSIZE + 1];
	sha1( userpwd, password );

	// print the 4 primary credentials:
    printf("\n****\n");
	printf( "Running Client with the following credentials...\n" );
	printf( "    Destination: %s\n", destination );
	printf( "    Port:        %d\n", portN );
	printf( "    User_ID:     %s\n", userid );
	printf( "    Password:    %s\n", userpwd );
	printf( "    Hashed_Pwd:  %s\n\n", password );
    printf("****\n\n");
	// ------------------------------------------------------------------


	// Space for command
	char buf[MAXTEXTSIZE];

	// ------------------------------------------------------------------
	// Create the socket
	int sock;
	if( ( sock = clientTCPsock( destination, portN ) ) < 0 ) {
		print_normal( "Failed to obtain TCP socket. \n" );
		exit( 1 );
	}
    // Message pointer
	Message *msg;
	// ------------------------------------------------------------------
	print_normal( "Connection established. Type a command to run on the Remote Shell...\n" );

	// Get the shell command from the user
	while( fgets( buf, sizeof( buf ), stdin ) ) {
        
        //printf( "\nbufsize: %d, text: %s\n", strlen( buf ), buf );
        
        // Quit program
		if( strlen( buf ) <= 1 )
			break;

		// Create a message for command RSHELL_REQ and send it.
		msg = create_message( RSHELL_REQ, userid, 0 );
        msg->paylen = IDSIZE + strlen( buf );
		msg->payload = buf;
		print_message( msg, "Sending" );
		write_message( sock, msg );
		free_msg( &msg, false );

		msg = recv_message( sock );
        print_message( msg, "Received" );
 
        switch ( msg->msgtype ) {
            case AUTH_REQ:
                //printf("in outer auth req");
                free_msg( &msg, false );

                // Create the AUTH_RESP message and send
                msg = create_message( AUTH_RESP, userid, 0 );
                msg->paylen = IDSIZE + strlen(password);
                msg->payload = password;
                print_message( msg, "Sending" );
                write_message( sock, msg );
                msg->payload = "\0";
                free(msg);

                msg = recv_message( sock );
                switch ( msg->msgtype ) {
                    case AUTH_SUCCESS:
                        print_message( msg, "Received" );
                        free_msg( &msg, false );
     
                        
                        bool wait = true;
                        while( wait ) {
                            msg = recv_message( sock );
                            if( msg->msgtype == RSHELL_RESULT_PART || msg->msgtype == RSHELL_RESULT_FINAL) {
                                print_message( msg, "Received" );
                                if( msg->paylen != IDSIZE ) {
                                    printf("****\n");
                                    if ( msg->msgtype == RSHELL_RESULT_PART ) {
                                        printf("Partial Section of command result:\n");
                                    } else {
                                        printf("Final Section of command result:\n");
                                    }
                                    printf( "%s\n", msg->payload );
                                    printf("****\n\n");
                                }
                                else {
                                    print_normal( "Command not found.\n" );
                                }
                                wait = ( msg->msgtype == RSHELL_RESULT_PART );
                                free_msg( &msg, wait );

                            }
                            else {
                                print_normal( "ERROR: Received Invalid message.\n" );
                                exit( 1 );
                            }
                        }
                        break;
                    case AUTH_FAIL:
                        print_message( msg, "Received" );
                        print_normal( "Authentication Failed!\n" );
                        free_msg( &msg, false );
                        exit( 1 );
                        break;
                    default:
                        print_normal( "ERROR: Received Invalid message.\n" );
                        exit( 1 );
                        break;
                }
                break;
            case RSHELL_RESULT_PART:
                printf("");
                bool wait = true;
                while( wait ) {
                    if( msg->msgtype == RSHELL_RESULT_PART || msg->msgtype == RSHELL_RESULT_FINAL) {
                        print_message( msg, "Received" );
                        if( msg->paylen != IDSIZE) {
                            printf("****\n");
                            if ( msg->msgtype == RSHELL_RESULT_PART ) {
                                printf("Partial Section of command result:\n");
                            } else {
                                printf("Final Section of command result:\n");
                            }
                            printf( "%s\n", msg->payload );
                            printf("****\n\n");
                        }
                        else {
                            print_normal( "Command not found.\n" );
                        }
                        wait = ( msg->msgtype == RSHELL_RESULT_PART );
                        free_msg( &msg, wait );
                    }
                    else {
                        print_normal( "ERROR: Received Invalid message.\n" );
                        exit( 1 );
                    }
                    if (wait){
                        msg = recv_message( sock );
                    }
                }
                break;
            case RSHELL_RESULT_FINAL:
                //printf("in outer res final");
                if( msg->paylen != IDSIZE) {
                    printf("****\n");
                    printf("Final Section of command result:\n");
                    printf( "%s\n", msg->payload );
                    printf("****\n\n");
                    free_msg( &msg, true );
                }
                else {
                    print_normal( "Command not found.\n" );
                    free_msg( &msg, false );
                }
                break;

            default:
                print_normal( "ERROR: Received Invalid message.\n" );
                exit( 1 );
                break;
        }

		// Ask for another command
		printf( "**********************************************************************\n" );
		print_normal( "Type another command to run on the Remote Shell...\n" );
        buf[0] = "\0";
	}
	close( sock );
}



