/*
 *   CS 468 Sample Program
 * 
 *   This program is for educational purpose, and it can not be copied as part of your submission to CS 468 HWs
 *
 *  Header File for RShellClient1.c and RShellServer1.c
 * 
*/

// OpenSSL Imports
#include <openssl/sha.h>
#include <time.h>
#include <stdbool.h>

// Other Imports
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/errno.h>

// Definitions for message type
#define RSHELL_REQ 0x01
#define AUTH_REQ 0x02
#define AUTH_RESP 0x03
#define AUTH_SUCCESS 0x04
#define AUTH_FAIL 0x05
#define RSHELL_RESULT_PART 0x06
#define RSHELL_RESULT_FINAL 0x07

// Size in bytes of Message type
#define TYPESIZE 1

 // Size in bytes of Message payload length
#define LENSIZE 2

// Password size (in Hex)--> 20 bytes, 2 chars rep 1 byte, so 40 chars
#define PASSWDSIZE 40

// Max ID size: 16 - 1 = 15 bytes for id, 1 for null term
#define IDSIZE 16

// Max length of payload (2^16) = 65536
#define MAXPLSIZE 65536

// Max potential message size (2^1) + (2^2) + (2^16)
#define MAXMSGSIZE 65542

// Max text length (2^16)
#define MAXTEXTSIZE  65536

// Command size- sub
#define MAXBUFSIZE ((MAXPLSIZE - IDSIZE) - 1)

// provided code definitions
#define LINELEN     (MAXBUFSIZE - 20)
#define BUFSZ       (MAXBUFSIZE - 20)
#define resultSz    (MAXPLSIZE - 1)

// Debug print for encryption key
#define DEBUG_KEY  1


// ============================================================================================
// Typedef for the message format
// ============================================================================================
typedef struct Message
{
	// Message type
	char msgtype;
	// payload length in bytes
	short paylen;
	// id for the first 16 bytes of the payload
	char id[IDSIZE];
	// the payload
	char *payload;
} Message;

// ============================================================================================
// Method to create a message object (with memory allocation)
// ============================================================================================
Message* create_message( char msgtype, char* id, int plsize )
{
	Message *msg = (Message *) malloc( sizeof(Message) );
	msg->msgtype = msgtype;
	msg->paylen = IDSIZE + plsize;
	msg->id[0] = '\0';
	msg->payload = NULL;

	if( id ) {
		snprintf( msg->id, IDSIZE, "%s", id );
		//printf( "message created for %s\n", msg->id );
	}

	if( plsize > 0 ) {
		msg->payload = (char *) malloc( ( plsize + 1 ) * sizeof(char) );
	}

	return msg;
}

// ============================================================================================
// Method to free a message object
// ============================================================================================
void free_msg( Message **msg, bool bFreePayload )
{
	if( !( *msg ) )
		return;

	if( bFreePayload && ( *msg )->payload ) {
		free( ( *msg )->payload );
		( *msg )->payload = NULL;
	}

	free( ( *msg ) );
	*msg = NULL;
}

// ============================================================================================
// Method to determine the message type
// ============================================================================================
// Method to determine the message type.
int decode_type( Message *msg, char *inOut )
{
	switch ( msg->msgtype ) {
		case RSHELL_REQ:
			printf( "%s RSHELL_REQ message.\n", inOut );
			return 1;
			break;
		case AUTH_REQ:
			printf( "%s AUTH_REQ message.\n", inOut );
			return 2;
			break;
		case AUTH_RESP:
			printf( "%s AUTH_RESP message.\n", inOut );
			return 3;
			break;
		case AUTH_SUCCESS:
			printf( "%s AUTH_SUCCESS message.\n", inOut );
			return 3;
			break;
		case AUTH_FAIL:
			printf( "%s AUTH_FAIL message.\n", inOut );
			return 5;
			break;
		case RSHELL_RESULT_PART:
			printf( "%s RSHELL_RESULT_PART message.\n", inOut );
			return 6;
			break;
        case RSHELL_RESULT_FINAL:
            printf( "%s RSHELL_RESULT_FINAL message. \n", inOut );
            return 7;
            break;
		default:
			printf( "ERROR: %s Invalid message.\n", inOut );
			return -1;
			break;
	}
}

// ============================================================================================
// Debug method to print a Message
// ============================================================================================
void print_message( Message *msg, char *inOut )
{
    if (DEBUG_KEY == 0){
        return;
    }
    
	if( !msg ) {
		printf( "Trying to print Null MSG" );
		exit( 1 );
	}
    
    printf("    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    
	if( inOut ) {
        printf("    ");
		decode_type( msg, inOut );
	}

	printf( "    PAYLEN:%d  ID:%s  PAYLOAD:\n", msg->paylen, msg->id );

	if( msg->paylen != IDSIZE ) {
        printf( "    %s\n", msg->payload );
	}
	printf("    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
}
// ============================================================================================
// Writes key messages that are not Message Packets
// ============================================================================================
void print_normal( const char * text){
    printf("\n****\n");
    printf("%s", text);
    printf("****\n\n");
}

// ============================================================================================
// Writes messages to socket: Returns 0 if successful, 1 if there was an error
// ============================================================================================
int write_message( int sock, Message *msg )
{
	// n will store the return value of write()
	int n;

	// Write the message type
	if( ( n = write( sock, &msg->msgtype, TYPESIZE ) ) != TYPESIZE ) {
		printf( "ERROR: Has %d byte send when trying to send %d bytes for Message Type: `%s`\n", n, TYPESIZE, &msg );
		close( sock );
		return -1;
	}

	// Write the message length
	if( ( n = write( sock, &msg->paylen, LENSIZE ) ) != LENSIZE ) {
		printf( "ERROR: Has %d byte send when trying to send %d bytes for Message Length: `%s`\n", n, LENSIZE, &msg );
		close( sock );
		return -1;
	}

	// Write the user ID
	if( msg->paylen >= IDSIZE ) {
		if( ( n = write( sock, &msg->id, IDSIZE ) ) != IDSIZE ) {
			printf( "ERROR: Has %d byte send when trying to send %d bytes for Message UserID: `%s`\n", n, IDSIZE, &msg );
			close( sock );
			return -1;
		}
	}

	// Write the payload
	if( msg->paylen > IDSIZE ) {
		if( ( n = write( sock, msg->payload, ( msg->paylen - IDSIZE ) ) ) != ( msg->paylen - IDSIZE ) ) {
			printf( "ERROR: Has %d byte send when trying to send %d bytes for Message Payload: `%s`\n", n, ( msg->paylen - IDSIZE ), &msg );
			close( sock );
			return -1;
		}
	}

	return 0;
}


// ============================================================================================
// SHA1 and SHA256 methods
// ============================================================================================
void sha1( char *string, char *outputBuffer )
{
	int i;

	unsigned char hash[SHA_DIGEST_LENGTH];
	SHA_CTX ctx;
	SHA1_Init( &ctx );
	SHA1_Update( &ctx, string, strlen( string ) );
	SHA1_Final( hash, &ctx );

	// Reformat the hash: 2 chars at a time for 1 byte each from temp hash
	for(i = 0; i < SHA_DIGEST_LENGTH; i++ ) {
		sprintf( outputBuffer + ( i * 2 ), "%02x", hash[i] );
	}
	outputBuffer[PASSWDSIZE] = '\0';
}
