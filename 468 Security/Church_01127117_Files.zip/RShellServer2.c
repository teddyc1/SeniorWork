/*
*  CS 468 Sample Program
*
*  This program is for educational purpose, and it can not be copied as part of your submission to CS 468 HWs
*/

#include "RShellHeader1.h"
#include <time.h>
#include <stdlib.h>

// ============================================================================================
// Method to create a server sock
// ============================================================================================
int serversock( int UDPorTCP, int portN, int qlen )
{
	struct sockaddr_in svr_addr; /* my server endpoint address       */
	int sock; /* socket descriptor to be allocated    */

	if( portN < 0 || portN > 65535 || qlen < 0 ) /* sanity test of parameters */
		return -2;

	bzero( (char *) &svr_addr, sizeof( svr_addr ) );
	svr_addr.sin_family = AF_INET;
	svr_addr.sin_addr.s_addr = INADDR_ANY;

	/* Set destination port number */
	svr_addr.sin_port = htons( portN );

	/* Allocate a socket */
	sock = socket( PF_INET, UDPorTCP, 0 );
	if( sock < 0 )
		return -3;

	/* Bind the socket */
	if( bind( sock, (struct sockaddr *) &svr_addr, sizeof( svr_addr ) ) < 0 )
		return -4;

	if( UDPorTCP == SOCK_STREAM && listen( sock, qlen ) < 0 )
		return -5;

	return sock;
}

int serverTCPsock( int portN, int qlen )
{
	return serversock( SOCK_STREAM, portN, qlen );
}

int serverUDPsock( int portN )
{
	return serversock( SOCK_DGRAM, portN, 0 );
}

// reaper - clean up zombie children
void reaper( int signum )
{
	int status;
	while( wait3( &status, WNOHANG, (struct rusage *) 0 ) >= 0 )
		/* empty */;
}

// ============================================================================================
// Modified Remote Shell method, builds and sends message(s) for remote shell command
// ============================================================================================
Message * MsgRemoteShell(char *command, char *id, int sock){
    char result[MAXTEXTSIZE + 1];
	FILE *fp;

	memset( result, 0, MAXTEXTSIZE );

	if( ( fp = popen( command, "r" ) ) == NULL ) {
		/* stream open failed */
		print_normal( "Stream open failed.\n" );
		exit( 1 );
	}

	// Combine stderr and stdout in command
	strcat( command, " 2>&1" );

	// read result of execution
	fread( result, MAXTEXTSIZE, 1, fp );
	result[MAXTEXTSIZE] = '\0';
	pclose( fp );

    printf("****\n");
	printf( "The result from command '%s' was length %d:\n%s\n", command, strlen( result ), result );
    printf("****\n\n");
    
	char msg_block[MAXTEXTSIZE];

	Message *msg = create_message( RSHELL_RESULT_PART, id, 0 );

    if (strlen ( result) == 0){
        msg->msgtype = RSHELL_RESULT_FINAL;
        msg->paylen = IDSIZE;
        msg->payload = "\0";
        print_message( msg, "Sending" );
        write_message( sock, msg );
    }
    
    char * data = result;
	while( strlen( data ) > 0 ) {
		snprintf( msg_block, MAXPLSIZE + 1, "%s", data );
        //printf("msg_block text: %s \n", msg_block);
        msg->paylen = IDSIZE + strlen( msg_block );
        msg->payload = msg_block;

		if( strlen( data ) > MAXPLSIZE ) {
            msg->msgtype = RSHELL_RESULT_PART;
			data += MAXPLSIZE;
		}
		else {
            msg->msgtype = RSHELL_RESULT_FINAL;
			data[0] = '\0';
		}
		print_message( msg, "Sending" );
		write_message( sock, msg );
	}
	free_msg( &msg, false );
}


// ============================================================================================
// Method to read messages from the socket, returns NULL if there is an error during read
// ============================================================================================
Message *read_message( int sock )
{
	// Create a pointer to hold in the message read-in
	Message *msg = (Message *) malloc( sizeof(Message) );

	// Read the message type
	if( read( sock, &msg->msgtype, TYPESIZE ) != TYPESIZE ) {
		// printf("ERROR(1): Could not read message type.\n");
		// Will reach here when client disconnects.
		print_normal( "Client has disconnected from the Server.\n" );
		free( msg );
		return NULL;
	}

	// Read the message length
	if( read( sock, &msg->paylen, LENSIZE ) != LENSIZE ) {
		print_normal( "ERROR(2): Could not read message length.\n" );
		free( msg );
		return NULL;
	}

	// Read the user ID
	if( msg->paylen >= IDSIZE ) {
		if( ( read( sock, &msg->id, IDSIZE ) ) != IDSIZE ) {
			print_normal( "ERROR(3): Could not read message ID.\n" );
			free( msg );
			return NULL;
		}
	}

	// Read the payload: malloc new memory for the incoming payload
	if( msg->paylen > IDSIZE ) {
		msg->payload = (char*) malloc( ( msg->paylen - IDSIZE + 1 ) * sizeof(char) );
		if( ( read( sock, msg->payload, ( msg->paylen - IDSIZE ) ) ) != ( msg->paylen - IDSIZE ) ) {
			print_normal( "ERROR(4): Could not read message payload.\n" );
			free_msg( &msg, true );
			return NULL;
		}
		msg->payload[msg->paylen - IDSIZE] = '\0';
	}

	// Return pointer to read-in message
	return msg;
}

// ============================================================================================
// Method to Authenticate sent client information with user/pass in password file
// ============================================================================================
// Simple function for authentication
// Takes Client username, SHA1 hashed client password and compares to
// Server username and server SHA1 hashed password
bool authenticate (char *cluser, unsigned char *clpass, char *seruser, unsigned char *serpass)
{
    if(strcmp(cluser, seruser) == 0){
        if(strcmp(clpass, serpass) == 0){
            print_normal("Authentication Success!\n\n");
            return true;
        }else{
            print_normal("Authentication Fail: Password did not match.\n\n");
        }
    }else{
        printf("Authentication Fail: Invalid ID -> %s\n\n", cluser);
    }
    return false;
}



/*------------------------------------------------------------------------
 * main - Concurrent TCP server
 *------------------------------------------------------------------------
 */
int
main(int argc, char *argv[])
{
    // Make sure there are 3 input arguments
	if( argc != 3 ) {
		fprintf( stderr, "Usage: %s <port to run server on> <password file>\n", argv[0] );
		exit( 1 );
	}

	// ------------------------------------------------------------------
	// Command line arg variables
	//
	// Set port number to run server on
	int portN = atoi( argv[1] );

	// Server password file name
	char *pwdfname = argv[2];
	unsigned char *password;

	// Username stored on the server read from the passwdfile.txt
	char *seruser;

	// SHA1 hashed password stored on the server read from the passwdfile.txt
	unsigned char *serpass;
	// I'm going to generate the Nonce here and use it for the communication
	srand(time(NULL));
	int nonce1 = rand();
	// Open and read the password file
	// The file should only have 1 line containing the format: <Username>; <hex representation of SHA1(PW)>
	// Example if the User was "Alice" and the password was "SecretPW":
	//      Alice; 0c8f72ea98dc74c71f9ff5bb72941036ae5120d9
	// Will parse the first line of the password file for the username and SHA1 password hash
	// Will first read line for username until finds the ";" symbol
	// Then after the ";" symbol will ignore whitespace and save the SHA1 hash in "hashedpass"
	char *userinfo = (char *) malloc( 128 * sizeof(char) );
	size_t linelen = 0;
	FILE *passwdfile = fopen( pwdfname, "r" );
	if( passwdfile == 0 ) {
		print_normal( "The specified password file was not found or could not be opened.\n" );
		exit( 1 );
	}
	ssize_t read = getline( &userinfo, &linelen, passwdfile );
	fclose( passwdfile );

	// Split on ";" symbol, get username
	char *linebuf = userinfo;
	seruser = strtok( linebuf, ";" );

	// Trim lead whitespace before the SHA1 password hash
	// Get rid of the ending newline character from SHA1 hash
	linebuf = strtok( NULL, ";" );
	while( isspace( *linebuf ) ) {
		linebuf++;
	}
	serpass = strtok( linebuf, "\n" );

	//printf( "User name %d: %s\n", strlen( seruser ), seruser );
	//printf( "User password %d: %s\n", strlen( serpass ), serpass );
	// ------------------------------------------------------------------

    // Variable that is true when the user is authenticated (successful login) or false if otherwise
    // After 60 seconds of authentication, should revert back to false
    bool auth = false;
    // Epoch times for calculatings 60 seconds past auth
    // Time of authentication
    struct timeval authtime;
    // Time of request for command
    struct timeval reqtime;

	// Command that the user wants to run on the RShell
	char *rshellcmd = (char *) malloc( 1000 * sizeof(char) );
	rshellcmd[0] = '\0';

	// ------------------------------------------------------------------
	// Server Vars
	int msock; 	// master server socket
	int ssock; 	// slave server socket
	struct sockaddr_in fromAddr; // the from address of a client
	unsigned int fromAddrLen; 	 // from-address length

	msock = serverTCPsock( portN, 5 );
	(void) signal( SIGCHLD, reaper );

    // ------------------------------------------------------------------
    while( 1 ) {
		fromAddrLen = sizeof( fromAddr );
		ssock = accept( msock, (struct sockaddr *) &fromAddr, &fromAddrLen );
		if( ssock < 0 ) {
			if( errno == EINTR )
				continue;
			print_normal( "accept error\n" );
		}

		// The user ID.
		char id[IDSIZE];
		// The message pointer
		Message *msg;
        // boolean to track auth timer
        bool auth = false;
        
        switch (fork())
        {
            case 0:     /* child */
                close(msock);

                // Print new connection message
                print_normal("Client has connected to the Server.\n"); 

                // Listen for client message 
                while(msg = read_message(ssock)){
                    if(msg != NULL){
                        print_message(msg, "Received");

                        gettimeofday(&reqtime,NULL);
                        if( (reqtime.tv_sec - authtime.tv_sec) > 60){
                            print_normal("More than 60 seconds have passed, setting user authentication to false.\n\n");
                            auth = false;
                        }

                        if(!auth){
                            switch(msg -> msgtype){
                                case RSHELL_REQ :
                                    // Save the command the user wants to run
                                    rshellcmd = (char*)malloc( (msg->paylen - IDSIZE) * sizeof(char));
                                    memcpy(rshellcmd, msg->payload, strlen(msg->payload));
                                    rshellcmd[(msg->paylen - IDSIZE) ] = '\0';
                                    //printf("The RShell command the user wants to run is: %s\n\n", rshellcmd);
                                    
                                    // Copy the from the message into the server id field
                                    memcpy(id,msg->id,IDSIZE);
                                    free_msg(&msg, false);

                                    msg = create_message( AUTH_REQ, id, 0 );
                                    msg->payload = '\0';

                                    // Write the AUTH REQ MESSAGE
                                    print_message(msg, "Sending");
                                    write_message(ssock, msg);
                                    free_msg(&msg, true);
                                    break;
                                case AUTH_RESP :
                                    password = (char*)malloc( PASSWDSIZE * sizeof(char) + 1);
                                    strcpy(password, msg->payload);

                                    if(authenticate (id, password, seruser, serpass)){
                                        free(password);
                                        auth = true;
                                        gettimeofday(&authtime,NULL);
                                        free_msg(&msg, true);

                                        // Create a an AUTH_SUC message
                                        msg = create_message( AUTH_SUCCESS, id, 0);
                                        msg->payload = '\0';

                                        // Write the AUTH SUCCESS
                                        print_message(msg, "Sending");
                                        write_message(ssock, msg);
                                        free_msg(&msg, false);

                                        /*
                                        RUN COMMAND AND RETURN RESULT
                                        */

                                        //print_normal("The RShell command to be run on the Server is: %s\n\n", rshellcmd);

                                        MsgRemoteShell(rshellcmd, id, ssock);

                                        // Free rshellcmd
                                        free(rshellcmd);

                                        break;
                                    }else{
                                        free(password);
                                        auth = false;

                                        // Free the current message
                                        free_msg(&msg, true);
                                        msg = create_message( AUTH_FAIL, id, 0);
                                        msg->payload = '\0';

                                        print_message(msg, "Sending");
                                        write_message(ssock, msg);
                                        free_msg( &msg, false);
                                    }
                                    break;
                                default :
                                    print_normal("ERROR: Received Invalid message.\n");
                                    break;
                            }
                        }else{
                            // The user has already been authenticated, just run command
                            printf("****\n");
                            printf("The user %s has already been authenticated. Will run command.\n", id);
                            printf("****\n\n");
                            switch(msg -> msgtype){
                                case RSHELL_REQ :
                                    rshellcmd = (char*)malloc( (msg->paylen - IDSIZE) * sizeof(char));
                                    memcpy(rshellcmd, msg->payload, strlen(msg->payload));
                                    rshellcmd[(msg->paylen - IDSIZE) ] = '\0';
                                    
                                    memcpy(id,msg->id,IDSIZE);
                                    //printf("THE ID FROM THE CLIENT IS: %s\n", id);
                                    free_msg(&msg, true);

                                    /*
                                    RUN COMMAND AND RETURN RESULT
                                    */

                                    //print_normal("The RShell command to be run on the Server is: %s\n\n", rshellcmd);

                                    MsgRemoteShell(rshellcmd, id, ssock);

                                    // Free rshellcmd
                                    free(rshellcmd);
                                    break;
                                default :
                                    print_normal("ERROR: Received Invalid message.\n");
                                    break;
                            }
                        }
                    }
                }
                close(ssock);
                exit(1);

            default:    /* parent */
                (void) close(ssock);
                break;
            case -1:
                print_normal("fork error\n");
        }
    }
    close(msock);
}
